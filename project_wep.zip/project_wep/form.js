const form = document.getElementById("userForm");
const usernameInput = document.getElementById("username");
const emailInput = document.getElementById("email");
const formTitle = document.getElementById("formTitle");

const LOCAL_KEY = 'usersData';
const editId = localStorage.getItem("editId");

let users = JSON.parse(localStorage.getItem(LOCAL_KEY)) || [];

if (editId) {
  formTitle.textContent = " تعديل المستخدم";
  const user = users.find(u => u.id == editId);
  if (user) {
    usernameInput.value = user.name;
    emailInput.value = user.email;
  }
}

form.addEventListener("submit", (e) => {
  e.preventDefault();

  const name = usernameInput.value.trim();
  const email = emailInput.value.trim();

  if (!name || !email) {
    alert("يرجى ملء كل الحقول.");
    return;
  }

  if (editId) {
    users = users.map(user =>
      user.id == editId ? { ...user, name, email } : user
    );
  } else {
    const newId = users.length ? Math.max(...users.map(u => u.id)) + 1 : 1;
    users.push({ id: newId, name, email });
  }

  localStorage.setItem(LOCAL_KEY, JSON.stringify(users));
  alert(" تم الحفظ بنجاح!");
  window.location.href = "table_users.html";
});