-- إنشاء قاعدة البيانات
CREATE DATABASE CollegeSystem;
USE CollegeSystem;

-- جدول الطلاب
CREATE TABLE Students (
    StudentID INT PRIMARY KEY,
    Name VARCHAR(100),
    Email VARCHAR(100),
    Gender CHAR(1),
    Level VARCHAR(20)
);

-- جدول الكورسات
CREATE TABLE Courses (
    CourseID INT PRIMARY KEY,
    CourseName VARCHAR(100),
    Credits INT
);

-- جدول ربط الطلاب بالكورسات
CREATE TABLE Student_Courses (
    StudentID INT,
    CourseID INT,
    Grade DECIMAL(5,2),
    PRIMARY KEY (StudentID, CourseID),
    FOREIGN KEY (StudentID) REFERENCES Students(StudentID),
    FOREIGN KEY (CourseID) REFERENCES Courses(CourseID)
);

-- بيانات الطلاب (10 طلاب)
INSERT INTO Students VALUES
(1, 'Ahmed Mohamed', 'ahmed@example.com', 'M', 'First Year'),
(2, 'Sarah Ali', 'sarah@example.com', 'F', 'Second Year'),
(3, 'Mohamed Hassan', 'mohamed@example.com', 'M', 'Third Year'),
(4, 'Layla Sameer', 'layla@example.com', 'F', 'First Year'),
(5, 'Ali Mahmoud', 'ali@example.com', 'M', 'Second Year'),
(6, 'Hind Ahmed', 'hind@example.com', 'F', 'Third Year'),
(7, 'Karim Youssef', 'karim@example.com', 'M', 'First Year'),
(8, 'Menna Khaled', 'menna@example.com', 'F', 'Second Year'),
(9, 'Rami Sami', 'rami@example.com', 'M', 'Third Year'),
(10, 'Dina Mostafa', 'dina@example.com', 'F', 'First Year');

-- بيانات الكورسات (10 كورسات)
INSERT INTO Courses VALUES
(101, 'Database Systems', 3),
(102, 'Mathematics I', 4),
(103, 'Programming', 4),
(104, 'English Language', 3),
(105, 'Physics', 4),
(106, 'Chemistry', 4),
(107, 'History', 2),
(108, 'Geography', 2),
(109, 'Philosophy', 3),
(110, 'Computer Science', 4);


-- درجات بعض الطلاب في بعض الكورسات
INSERT INTO Student_Courses VALUES
(1, 101, 85.5),
(1, 102, 90.0),
(2, 101, 78.0),
(2, 103, 88.0),
(3, 102, 65.0),
(4, 104, 88.0),
(5, 105, 75.5),
(6, 106, 70.0),
(7, 107, 80.0),
(8, 108, 85.0),
(9, 109, 77.0),
(10, 110, 92.0);

-- عدد الطلاب
SELECT COUNT(*) AS TotalStudents FROM Students;

-- عدد الكورسات
SELECT COUNT(*) AS TotalCourses FROM Courses;

-- متوسط درجات كل طالب
SELECT s.StudentID, s.Name, AVG(sc.Grade) AS AverageGrade
FROM Students s
JOIN Student_Courses sc ON s.StudentID = sc.StudentID
GROUP BY s.StudentID, s.Name;

-- أعلى درجة في كل كورس
SELECT c.CourseName, MAX(sc.Grade) AS HighestGrade
FROM Courses c
JOIN Student_Courses sc ON c.CourseID = sc.CourseID
GROUP BY c.CourseName;

-- أقل درجة في كل كورس
SELECT c.CourseName, MIN(sc.Grade) AS LowestGrade
FROM Courses c
JOIN Student_Courses sc ON c.CourseID = sc.CourseID
GROUP BY c.CourseName;

-- عدد الكورسات اللي كل طالب مسجل فيها
SELECT s.Name, COUNT(sc.CourseID) AS NumberOfCourses
FROM Students s
LEFT JOIN Student_Courses sc ON s.StudentID = sc.StudentID
GROUP BY s.Name;
