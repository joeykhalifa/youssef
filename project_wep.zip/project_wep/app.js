const LOCAL_KEY = 'usersData';
async function loadUsers() {
  let users = JSON.parse(localStorage.getItem(LOCAL_KEY));

  if (!users) {
    const res = await fetch('https://jsonplaceholder.typicode.com/users ');
    users = await res.json();
    localStorage.setItem(LOCAL_KEY, JSON.stringify(users));
  }

  renderTable(users);
}

function renderTable(users) {
  const tbody = document.querySelector("#userTable tbody");
  tbody.innerHTML = "";

  users.forEach(user => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${user.name}</td>
      <td>${user.email}</td>
      <td class="actions">
        <button onclick="editUser(${user.id})">✏️ تعديل</button>
        <button onclick="deleteUser(${user.id})">🗑️ حذف</button>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

function goToForm(id = null) {
  if (id !== null) {
    localStorage.setItem("editId", id);
  } else {
    localStorage.removeItem("editId");
  }
  window.location.href = "index.html";
}

function deleteUser(id) {
  if (!confirm("هل أنت متأكد من حذف المستخدم؟")) return;

  let users = JSON.parse(localStorage.getItem(LOCAL_KEY)) || [];
  users = users.filter(user => user.id !== id);
  localStorage.setItem(LOCAL_KEY, JSON.stringify(users));
  loadUsers();
}

document.addEventListener("DOMContentLoaded", loadUsers);

window.goToForm = goToForm;
window.deleteUser = deleteUser;
window.editUser = goToForm;